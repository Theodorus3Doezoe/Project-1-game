//dom variables for hud
let playerHp = document.getElementById("playerHp");
let playerRam = document.getElementById("playerRam");
let btc = document.getElementById("btc");
let enemyHp = document.getElementById("enemyHp");
const actionText = document.getElementById("actionText");
const playerName = document.getElementById("playerName");
const enemyName = document.getElementById("enemyName");
const gameOverContainer = document.getElementById("gameOverContainer");

//stored values
const player = {
    health: 100,
    ram: 25,
    btc: 15,
    name: ''
}

const abilities = [
    {name: "ddos",       power: 200, cost: 2},
    {name: "sql",        power: 15, cost: 2},
    {name: "bruteforce", power: 2,  cost: 2},
    {name: "ransomware", power: 5,  cost: 2, price: 1}
]

const enemies = [
    {name: "igor", health: 100, multiplier: 1},
    {name: "zlatan", health: 120, multiplier: 1.5},
    {name: "ivan", health: 160, multiplier: 2},
    {name: "vladimir", health: 200, multiplier: 2.5}
]

const enemyAbillities = [
    {name: "propaganda", power: 10},
    {name: "fakenews", power: 10},
    {name: "trolling", power: 10},
    {name: "censorship", power: 10}
]

const enemyIds = ["igor", "zlatan", "ivan", "vladimir"]
let enemyIndex = 0

let currentHealth = player.health
let currentRam = player.ram
let currentBtc = player.btc
let currentEnemyHp = enemies[enemyIndex].health

function updateHud() {
    playerHp.value = currentHealth
    playerRam.innerHTML = currentRam
    btc.innerHTML = currentBtc
    enemyHp.value = currentEnemyHp / enemies[enemyIndex].health * 100
}

function arrow() {
    document.getElementById("enemySelectionContainer").style.display="none"
    document.getElementById("homeSettings").style.display="flex"
}

document.getElementById("arrow").addEventListener("click", arrow)

//homepage 
const input = document.getElementById("nameField")
document.getElementById("startButton").addEventListener("click", () => {
    player.name = input.value
    if (player.name === '' || player.name.length <= 1){
        window.alert("You must enter a name!")
    } else {
        playerName.innerHTML = player.name
        currentHealth = player.health
        document.getElementById("homeSettings").style.display="none";
        document.getElementById("enemySelectionContainer").style.display="block";
        document.getElementById("characterImage").style.display="none";   
        actionText.innerHTML = `What will ${player.name} do?`
        updateHud()
    }
})

//Shop
document.getElementById("shopButton").addEventListener("click", () => {
    document.getElementById("shopContainer").style.display="block";
})


//Enemy selectionscreen
const enemyImageSource = ["./animations/igor/igor.gif", "./animations/zlatan/zlatan.gif", "./animations/ivan/ivan.gif" ,"./animations/vladimir/vladimir.gif"]

enemyIds.forEach(enemyId => {
    document.getElementById(enemyId).addEventListener("click", function () {
            enemyIndex = enemies.findIndex(function (enemy) {
            return enemy.name === enemyId
        })
        enemyName.innerHTML = enemies[enemyIndex].name
        currentEnemyHp = enemies[enemyIndex].health
        updateHud()
        document.getElementById("gameContainer").style.display="block" 
        document.getElementById("homepageContainer").style.display="none" 
        document.getElementById("enemyImage").src = enemyImageSource[enemyIndex];
        if (enemyId === "ivan" || enemyId === "zlatan") {
            document.getElementById("enemyHp").style.marginLeft="5vw"
            document.getElementById("enemyName").style.marginLeft="5vw"
        }
    })
})

//fight logic
function disableButtons() {
    for (let i = 0; i < buttonIds.length; i++) {
        document.getElementById(buttonIds[i]).setAttribute('disabled', '');
    }
}

function enableButtons() {
    for (let i = 0; i < buttonIds.length; i++) {
        document.getElementById(buttonIds[i]).removeAttribute('disabled', '');
        actionText.innerHTML = `What will ${player.name} do?`;
    }
}

//scallable button logic
const buttonIds =["ddos", "sql", "bruteforce", "ransomware"]

//Abilities logic
buttonIds.forEach(buttonId => {
    document.getElementById(buttonId).addEventListener("click", function () {
        let abilityIndex = abilities.findIndex(function (ability) {
            return ability.name === buttonId;
        })
        if (currentRam < abilities[abilityIndex].cost) {
            actionText.innerHTML = "You dont have enough ram for this ability!"
        } else if (currentBtc <= 0) {
            actionText.innerHTML = "You have ran out of BTC!"
        } else {
            switch(buttonId) {
                case "ddos":
                    currentRam -= abilities[0].cost
                    currentEnemyHp -= abilities[0].power
                    break;
                case "sql":
                    currentRam -= abilities[1].cost
                    currentEnemyHp -= abilities[1].power
                    break;
                case "bruteforce":
                    currentRam -= abilities[2].cost
                    let counter = 0;
                    const countInterval = setInterval(count, 1000)
                    function count() {
                        counter++
                        currentEnemyHp -= abilities[2].power
                        updateHud()
                        if(counter === 5) {
                            clearInterval(countInterval)
                        }
                    }
                    break;
                case "ransomware":
                    currentRam -= abilities[3].cost
                    currentEnemyHp -= abilities[3].power
                    currentBtc += abilities[3].price
                    break;
            }
            actionText.innerHTML = `${player.name} casts: ${buttonId}! <br> It deals ${abilities[abilityIndex].power} damage!`

            disableButtons()

            if (currentEnemyHp <= 0) {
                setTimeout(() => {
                    actionText.innerHTML = "You win!"
                    gameOverContainer.style.display="block";
                    document.getElementById("winLose").innerHTML = "Win"
                }, 2000)
            } else {
                setTimeout(() => {
                    actionText.innerHTML = `What will ${enemies[enemyIndex].name} do?`;
                }, 3000);
                let randomAbilityIndex = Math.floor(Math.random() * enemyAbillities.length)
                setTimeout(() => {
                    let damage = enemyAbillities[randomAbilityIndex].power * enemies[enemyIndex].multiplier
                    currentHealth -= damage
                    updateHud()
                    actionText.innerHTML = `${enemies[enemyIndex].name} casts ${enemyAbillities[randomAbilityIndex].name}! <br> It deals ${damage} damage`
                    if (currentHealth <= 0) {
                        setTimeout(() => {
                            actionText.innerHTML = "You lose!"
                            gameOverContainer.style.display="block";
                            document.getElementById("winLose").innerHTML = "Lose"
                        }, 2000)
                    } else {
                        setTimeout(enableButtons, 7000)
                    }
                }, 6000)
            }
        }
        updateHud()
    })
})

function restart() {
    document.getElementById("homepageContainer").style.display="flex"
    document.getElementById("homeSettings").style.display="flex"
    document.getElementById("gameContainer").style.display="none"
    document.getElementById("enemySelectionContainer").style.display="none"
    gameOverContainer.style.display="none";
    enableButtons()
}
document.getElementById("restartButton").addEventListener("click", restart)

//pause
document.getElementById("menuButton").addEventListener("click", () => {
    document.getElementById("menuContainer").style.display="grid";
    disableButtons()
})

document.getElementById("resumeButton").addEventListener("click", () => {
    document.getElementById("menuContainer").style.display="none";
    enableButtons()
})

document.getElementById("homeButton").addEventListener("click", () => {
    restart()
    document.getElementById("menuContainer").style.display="none";
})