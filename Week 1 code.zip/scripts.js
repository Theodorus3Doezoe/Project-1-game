//dom variables for hud
let playerHp = document.getElementById("playerHp");
let playerRam = document.getElementById("playerRam");
let btc = document.getElementById("btc");
let enemyHp = document.getElementById("enemyHp");

//stored values
const player = {
    health: 100,
    ram: 25,
    btc: 15
}

const abilities = [
    {name: "ddos",       power: 10, cost: 5},
    {name: "sql",        power: 15, cost: 10},
    {name: "bruteforce", power: 2,  cost: 7},
    {name: "ransomware", power: 5,  cost: 5, price: 10}
]

const enemies = [
    {name: "igor", health: 100, }
]

const enemyAbillities = [
    {name: "propaganda", power: 15},
    {name: "fakenews", power: 20},
    {name: "trolling", power: 8},
    {name: "censorship", power: 10}
]

//fight logic
//current resources
let currentHealth = player.health
let currentRam = player.ram
let currentBtc = player.btc
let currentEnemyHp = enemies[0].health //voor meerdere enemies dynamic maken

function updateHud() {
    playerHp.innerHTML = currentHealth
    playerRam.innerHTML = currentRam
    btc.innerHTML = currentBtc
    enemyHp.innerHTML = currentEnemyHp
}

updateHud()

//scallable button logic
const buttonIds =["ddos", "sql", "bruteforce", "ransomware"]

//Abilities logic
buttonIds.forEach(buttonId => {
    document.getElementById(buttonId).addEventListener("click", function () {
        let abilityIndex = abilities.findIndex(function (ability) {
            return ability.name === buttonId;
        })
        if (enemies[0].health < 1) {
            console.log("You win!")
        } else if (currentRam < abilities[abilityIndex].cost) {
            console.log("You dont have enough ram for this ability!")
        // } else if (playerRam.innerHTML <= 0) { //Doet op het moment niks door bovenstaande regel
        //     console.log("You have ran out of ram!")
        } else if (currentBtc <= 0) {
            console.log("You have ran out of BTC!")
        } else {
            switch(buttonId) {
                case "ddos":
                    currentRam -= abilities[0].cost
                    currentEnemyHp -= abilities[0].power
                    break;
                case "sql":
                    currentRam -= abilities[1].cost
                    currentEnemyHp -= abilities[1].power
                    break;
                case "bruteforce":
                    currentRam -= abilities[2].cost
                    let counter = 0;
                    const countInterval = setInterval(count, 1000)
                    function count() {
                        counter++
                        currentEnemyHp -= abilities[2].power
                        updateHud()
                        if(counter === 5) {
                            clearInterval(countInterval)
                        }
                    }
                    break;
                case "ransomware":
                    currentRam -= abilities[3].cost
                    currentEnemyHp -= abilities[3].power
                    currentBtc += abilities[3].price
                    break;
            }
        }
        updateHud()
        
        for (let i = 0; i < buttonIds.length; i++) {
            document.getElementById(buttonIds[i]).setAttribute('disabled', '');

            setTimeout(() => {
            document.getElementById(buttonIds[i]).removeAttribute('disabled', '');
            }, "5000");
        }

        // turn based logic
        let randomAbilityIndex = Math.floor(Math.random() * enemyAbillities.length)
        console.log(randomAbilityIndex)
        function enemyAttack() {
            currentHealth -= enemyAbillities[randomAbilityIndex].power
            updateHud()
            console.log(`${enemies[0].name} casts ${enemyAbillities[randomAbilityIndex].name}!` )
        }
        setTimeout(enemyAttack, 1000)
    })
})


